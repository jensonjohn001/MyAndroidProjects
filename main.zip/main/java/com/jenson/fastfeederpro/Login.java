package com.jenson.fastfeederpro;

import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.CycleInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;

import com.jenson.fastfeederpro.animations.FlipAnimation;

public class Login extends AppCompatActivity {
    EditText et_email,et_pass;

    Button sign_in,sign_up;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        et_email=(EditText)findViewById(R.id.email);
        et_pass=(EditText)findViewById(R.id.password);
        sign_in=(Button)findViewById(R.id.sign_in);


        sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                et_email.startAnimation(shakeError());
                et_pass.startAnimation(shakeError());

                Intent i =new Intent(getApplicationContext(),Home.class);
                startActivity(i);

            }
        });

        sign_up=(Button)findViewById(R.id.sign_up);


        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               /* et_email.startAnimation(shakeError());
                et_pass.startAnimation(shakeError());*/

               /* Intent i =new Intent(getApplicationContext(),OptimizedHome.class);
                startActivity(i);*/

            }
        });

    }

    public TranslateAnimation shakeError() {
        TranslateAnimation shake = new TranslateAnimation(0, 10, 0, 0);
        shake.setDuration(500);
        shake.setInterpolator(new CycleInterpolator(7));
        return shake;
    }

    public void onCardClick(View view)
    {
        flipCard();
    }

    private void flipCard()
    {
        View rootLayout = (View) findViewById(R.id.root_view);
        View cardFace = (View) findViewById(R.id.outer_frame_login);
        View cardBack = (View) findViewById(R.id.outer_frame_signup);

        FlipAnimation flipAnimation = new FlipAnimation(cardFace, cardBack);

        if (cardFace.getVisibility() == View.GONE)
        {
            flipAnimation.reverse();
        }
        rootLayout.startAnimation(flipAnimation);
    }
}
