package com.jenson.fastfeederpro.controllers;

import android.content.Context;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;

import com.jenson.fastfeederpro.INavigationdrawerController;
import com.jenson.fastfeederpro.INavigationdrawerControllerCallback;
import com.jenson.fastfeederpro.database.DbHelper;
import com.jenson.fastfeederpro.models.Article;
import com.jenson.fastfeederpro.network.Api;
import com.jenson.fastfeederpro.network.App;
import com.jenson.fastfeederpro.network.Apitags;

import java.lang.reflect.Type;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

/**
 * Created by Jenson on 06-Feb-18.
 */

public class HomeActivityController implements INavigationdrawerController {
    Context context;
    INavigationdrawerControllerCallback inavigationcallback;

   // Apis apis;

    public HomeActivityController(Context context, INavigationdrawerControllerCallback inavigationcallback) {
        this.context = context;
        this.inavigationcallback = inavigationcallback;
//        apis = App.getClient().create(Apis.class);
    }

    @Override
    public void fetchFeed(final String url) {
        Retrofit retrofit = App.getClient();
        Api service = retrofit.create(Api.class);
        service.dataGet(url).enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {


                    JsonObject responseObject = response.body();
                   // if (responseObject.has(Apitags.CATOGORY)) {
                        //JsonObject subcat = responseObject.getAsJsonObject(Apitags.CATOGORY);
                        JsonArray data = responseObject.getAsJsonArray(Apitags.DATA);
                        ArrayList<Article> myorder = getGeneral(data.toString());

                        inavigationcallback.navigationsuccess(myorder,url);
                   /* }

                    else {
                        Toast.makeText(context,"error",Toast.LENGTH_LONG).show();
                    }*/
                }
                else {

                    Toast.makeText(context, "failed to fetch", Toast.LENGTH_LONG).show();

                }

            }
            private ArrayList<Article> getGeneral(String s) {
                Gson gson = new Gson();
                Type listType = new TypeToken<ArrayList<Article>>() {
                }.getType();

                return gson.fromJson(s, listType);
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {

            }
        });

    }


}
