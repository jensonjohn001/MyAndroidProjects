package com.jenson.fastfeederpro.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.jenson.fastfeederpro.models.Article;

import java.util.ArrayList;
import java.util.List;

public class DbHelper extends SQLiteOpenHelper {



    public static final String DATABASE_NAME = "feed.db";
    private static final int DATABASE_VERSION = 1 ;
    public static final String TABLE_NAME = "Feeds";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_IMG_URL = "img_url";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_URL = "url";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_FEED_ID = "feed_id";



    public DbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(" CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_TITLE + " TEXT UNIQUE, " +
                COLUMN_FEED_ID + " TEXT, " +
                COLUMN_IMG_URL + " TEXT UNIQUE, " +
                COLUMN_DESCRIPTION + " TEXT UNIQUE, " +
                COLUMN_TIME + " TEXT UNIQUE, " +
                COLUMN_URL + " TEXT UNIQUE);"
        );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        this.onCreate(db);
    }

    /**create record**/
    public void saveFeed(ArrayList<Article> feedlist) {

        SQLiteDatabase db = this.getWritableDatabase();
        for (int i=0;i<feedlist.size();i++){

        ContentValues values = new ContentValues();
        values.put(COLUMN_TITLE, feedlist.get(i).getTitle());
        values.put(COLUMN_FEED_ID, feedlist.get(i).getSource().getId());
        values.put(COLUMN_IMG_URL, feedlist.get(i).getUrlToImage());
        values.put(COLUMN_DESCRIPTION, feedlist.get(i).getDescription());
        values.put(COLUMN_TIME,feedlist.get(i).getPublishedAt());
        values.put(COLUMN_URL, feedlist.get(i).getUrl());

        // insert
        db.insertWithOnConflict(TABLE_NAME,null, values,SQLiteDatabase.CONFLICT_REPLACE);
        }

        db.close();
    }

    public List<Article> getAllFeeds(String feedId) {
        List<Article> articlelList = new ArrayList<>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_NAME +" WHERE feed_id= '"+feedId+"'" ;


        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Article article = new Article();
                article.setTitle(cursor.getString(cursor.getColumnIndex(COLUMN_TITLE)));
                article.setUrlToImage(cursor.getString(cursor.getColumnIndex(COLUMN_IMG_URL)));
                article.setDescription(cursor.getString(cursor.getColumnIndex(COLUMN_DESCRIPTION)));

                article.setPublishedAt(cursor.getString(cursor.getColumnIndex(COLUMN_TIME)));
                article.setUrl(cursor.getString(cursor.getColumnIndex(COLUMN_URL)));

                articlelList.add(article);
            } while (cursor.moveToNext());
        }

        // close db connection
        db.close();


        return articlelList;
    }
}
