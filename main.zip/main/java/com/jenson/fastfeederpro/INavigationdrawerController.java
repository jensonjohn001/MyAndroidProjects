package com.jenson.fastfeederpro;

/**
 * Created by Jenson on 06-Feb-18.
 */

public interface INavigationdrawerController {
    void fetchFeed(String url);

}
