package com.jenson.fastfeederpro;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.jenson.fastfeederpro.adapters.HomeActivityAdapter;
import com.jenson.fastfeederpro.controllers.HomeActivityController;
import com.jenson.fastfeederpro.database.DbHelper;
import com.jenson.fastfeederpro.models.Article;
import com.wang.avi.AVLoadingIndicatorView;

import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Home extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener,INavigationdrawerControllerCallback {

    private AVLoadingIndicatorView avi;
    DbHelper dbHelper;
    Context mContext;

    //to get headlines
    StringBuilder sb = new StringBuilder();
    WebView wv;

    ProgressBar progressBar;
    RecyclerView rv;
    private INavigationdrawerController inavdrawcontroller;
    private List<Article> feedFromDB;
//tech
    private static final String techcrunch="v2/everything?sources=techcrunch&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String techradar="v2/everything?sources=techradar&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String wired="v2/everything?sources=wired&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String the_next_web= "v2/everything?sources=the-next-web&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String hacker_news="v2/everything?sources=hacker-news&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String ars_technica= "v2/everything?sources=ars-technica&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String crypto_coin= "v2/everything?sources=crypto-coins-news&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String engadget="v2/everything?sources=engadget&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String the_verge="v2/everything?sources=the-verge&apiKey=ef5b910bb4a047d289c7366e96d9d9df";

//science
    private static final String scientist= "v2/everything?sources=new-scientist&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String next_big_feature= "v2/everything?sources=next-big-future&apiKey=ef5b910bb4a047d289c7366e96d9d9df";

//news
    private static final String google_news= "v2/everything?q=bitcoin&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String google_news_IN= "v2/everything?q=bitcoin&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String google_news_SAUDI= "v2/everything?q=bitcoin&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String abc_news= "v2/everything?sources=abc-news&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String al_jazeera= "v2/everything?sources=al-jazeera-english&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String bbc_news= "v2/everything?sources=bbc-news&apiKey=ef5b910bb4a047d289c7366e96d9d9d";
///sports
    private static final String bbc_sports= "v2/everything?sources=bbc-sport&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String bleacher="v2/everything?sources=bleacher-report&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String footbal_italia="v2/everything?sources=football-italia&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String fox_sport="v2/everything?sources=fox-sports&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String bloomberg="v2/everything?sources=bloomberg&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
//business
    private static final String business_insider="v2/everything?sources=business-insider&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String cnbc="v2/everything?sources=cnbc&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String fin_post="v2/everything?sources=financial-post&apiKey=ef5b910bb4a047d289c7366e96d9d9df";
    private static final String fin_time="v2/everything?sources=financial-times&apiKey=ef5b910bb4a047d289c7366e96d9d9df";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

      /*  FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/

        wv=(WebView)findViewById(R.id.wv);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


       // progressBar=(ProgressBar)findViewById(R.id.progressBar);

        avi= (AVLoadingIndicatorView) findViewById(R.id.avi);
        mContext=Home.this;


        rv=(RecyclerView)findViewById(R.id.rv);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        rv.setLayoutManager(layoutManager);
        inavdrawcontroller = new HomeActivityController(getApplicationContext(), this);
        inavdrawcontroller.fetchFeed(techradar);








    }
    @Override
    public void navigationsuccess(ArrayList<Article> navdrawerlist,String feedId) {

        dbHelper=new DbHelper(mContext);
        dbHelper.saveFeed(navdrawerlist);

        String feedID = StringUtils.substringBetween(feedId, "=", "&");
        //Toast.makeText(mContext,feedID,Toast.LENGTH_SHORT).show();
        this.feedFromDB =dbHelper.getAllFeeds(feedID);


        HomeActivityAdapter adapter = new HomeActivityAdapter(feedFromDB);


        //random color
        Random random = new Random();
        for (int i = 0; i < navdrawerlist.size(); i++) {
            // create a big random number - maximum is ffffff (hex) = 16777215 (dez)
            int nextInt = random.nextInt(256 * 256 * 256);
            // format it as hexadecimal string (with hashtag and leading zeros)
            String colorCode = String.format("#%06x", nextInt);

            sb.append("***<font color=" + colorCode + ">");
            sb.append(navdrawerlist.get(i).getTitle());
            sb.append("</font>***");
        }

        String headline= sb.toString();

        String data = "<html><body><h6><marquee>"+headline+"</marquee></h6></body></html>";
        wv.loadData(data, "text/html", "UTF-8");

       // progressBar.setVisibility(View.GONE);
        avi.hide();
        rv.setAdapter(adapter);

        adapter.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(Article item) {

                Intent intent=new Intent(getApplicationContext(),FeedContent.class);
                intent.putExtra("title",item.getTitle().toString());
                intent.putExtra("thumb",item.getUrlToImage());
                intent.putExtra("content",item.getDescription());
                intent.putExtra("contentURL",item.getUrl());

                startActivity(intent);
                // Toast.makeText(Main2Activity.this, item.getTitle(), Toast.LENGTH_SHORT).show();

            }
        });


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_fav) {
            Intent i=new Intent(getApplicationContext(),About.class);
            startActivity(i);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.techcrunch) {
            inavdrawcontroller.fetchFeed(techcrunch);
        } else if (id == R.id.tech_radar) {
            inavdrawcontroller.fetchFeed(techradar);
        } else if (id == R.id.wired) {
            inavdrawcontroller.fetchFeed(wired);
        } else if (id == R.id.the_next_web) {
            inavdrawcontroller.fetchFeed(the_next_web);
        } else if (id == R.id.hacker_news) {
            inavdrawcontroller.fetchFeed(hacker_news);
        } else if (id == R.id.ars_technica) {
            inavdrawcontroller.fetchFeed(ars_technica);
        } else if (id == R.id.crypto_coin) {
            inavdrawcontroller.fetchFeed(crypto_coin);
        } else if (id == R.id.en_gadget) {
            inavdrawcontroller.fetchFeed(engadget);
        } else if (id == R.id.the_verge) {
            inavdrawcontroller.fetchFeed(the_verge);
        }


        else if (id == R.id.google_news) {
            inavdrawcontroller.fetchFeed(google_news);
        } else if (id == R.id.google_news_IN) {
            inavdrawcontroller.fetchFeed(google_news_IN);
        } else if (id == R.id.google_news_SAUDI) {
            inavdrawcontroller.fetchFeed(google_news_SAUDI);
        } else if (id == R.id.abc_news) {
            inavdrawcontroller.fetchFeed(abc_news);
        } else if (id == R.id.al_jazeera) {
            inavdrawcontroller.fetchFeed(al_jazeera);
        } else if (id == R.id.bbc_news) {
            inavdrawcontroller.fetchFeed(bbc_news);
        }


        else if (id == R.id.bbc_sports) {
            inavdrawcontroller.fetchFeed(bbc_sports);
        } else if (id == R.id.bleacher) {
            inavdrawcontroller.fetchFeed(bleacher);
        } else if (id == R.id.footbal_italia) {
            inavdrawcontroller.fetchFeed(footbal_italia);
        } else if (id == R.id.fox_sport) {
            inavdrawcontroller.fetchFeed(fox_sport);
        } else if (id == R.id.bloomberg) {
            inavdrawcontroller.fetchFeed(bloomberg);
        }

        else if (id == R.id.business_insider) {
            inavdrawcontroller.fetchFeed(business_insider);
        } else if (id == R.id.cnbc) {
            inavdrawcontroller.fetchFeed(cnbc);
        } else if (id == R.id.fin_post) {
            inavdrawcontroller.fetchFeed(fin_post);
        } else if (id == R.id.fin_time) {
            inavdrawcontroller.fetchFeed(fin_time);
        }

        else if (id == R.id.scientist) {
            inavdrawcontroller.fetchFeed(scientist);
        } else if (id == R.id.next_big_feature) {
            inavdrawcontroller.fetchFeed(next_big_feature);
        }



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
