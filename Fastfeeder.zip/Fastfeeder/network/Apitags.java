package com.jenson.fastfeederpro.network;

/**
 * Created by Jenson on 06-Feb-18.
 */

public class Apitags {
    public static final String KEY ="product_id";
    public static final String DATA ="articles";
}
